export const CreateShippingColoumn = [
    {
        Header: 'S.no',
        sticky: 'left'
    },

    {
        Header: 'Coustomer Name',
      
    },
    {
        Header: 'Identifier',
       

    },
    {
        Header: 'Identifier Type',
      
    },
    {
        Header: 'Quantity Ordered',
      
    },
    {
        Header: 'Quantity Shipment',

    }
]