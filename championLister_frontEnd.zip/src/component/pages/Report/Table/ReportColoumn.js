export const ReportColoumnn = [
    {
      Header: 'Date',
    },
   
    {
      Header: 'Channel',
    },
    {
      Header: 'Total',
         
    },
    {
      Header: 'Profit Earn',
    
    }
  ]