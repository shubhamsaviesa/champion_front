import React from 'react'

const ViewDetails = () => {
  return (
    <div>Edit Mapping</div>
  )
}
export default ViewDetails