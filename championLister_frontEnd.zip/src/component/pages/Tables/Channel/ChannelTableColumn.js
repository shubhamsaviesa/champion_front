export const ChannelTableColumn = [
    {
        Header: 'S.no',
        accessor: 'sn',
        sticky: 'left'
    },

    {
        Header: 'Name',
        accessor: 'bookName',
        sticky: 'left'
    },
    {
        Header: 'Identifier',
        accessor: 'itemCond',

    },
    {
        Header: 'Category',
        accessor: 'channel'
    },
    {
        Header: 'Variants',
        accessor: 'profit',
    },
    {
        Header: 'Quantity',

    },
    {
        Header: 'Status',

    },
    {
        Header: 'Price',
    },
    {
        Header: 'Last Modified',
    }
]