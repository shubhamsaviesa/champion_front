// const Api_url = "http://localhost:5000/api/user";
const Api_url = "http://api.championlister.com/api/user";
export default Api_url;
