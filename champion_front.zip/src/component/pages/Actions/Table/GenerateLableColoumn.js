export const GenerateLableColoumn = [
    {
        Header: 'S.no',
       
    },

    {
        Header: 'Shipping ID',
        
    },
    {
        Header: 'Item Name',
        accessor: 'itemCond',

    },
    {
        Header: 'Quantity',
        
    },
    {
        Header: 'Payment',
      
    },
    {
        Header: 'Payment Status',

    }
]