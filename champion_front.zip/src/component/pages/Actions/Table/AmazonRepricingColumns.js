export const AmazonRepricingColumns = [
    {
        Header: 'S.no',
        accessor: 'sn',
        sticky: 'left'
    },

    {
        Header: 'Marketplace',
        accessor: 'bookName',
        sticky: 'left'
    },
    {
        Header: 'Range 0-20',
        accessor: 'itemCond',

    },
    {
        Header: 'Range 21-40',
        accessor: 'channel'
    },
    {
        Header: 'Range 41-60',
        accessor: 'profit',

    },
    {
        Header: 'Range 61-80',
        accessor: "Status"
    },
    {
        Header: 'Range 81-100',
      
    },
    {
        Header: 'Range 101-10000',
       
    }
]