export const COLUMNS = [
  {
    Header: "Template Name",
    accessor: "tempName",
  },
  {
    Header: "Abbreviation",
    accessor: "abbrevation",
  },
  {
    Header: "Status",
    accessor: "status",
  },
  {
    Header: "SKU",
    accessor: "sku",
  },
];
