export const ShipmentColumns = [
    {
        Header: 'S.no',
        accessor: 'sn',
        sticky: 'left'
    },

    {
        Header: 'Name',
        accessor: 'bookName',
        sticky: 'left'
    },
    {
        Header: 'Customer Name',
        accessor: 'itemCond',

    },
    {
        Header: 'Shipping Id',
        accessor: 'channel'
    },
    {
        Header: 'Shipping Type',
        accessor: 'profit',
    },
    {
        Header: 'Shipping Address',

    },
    {
        Header: 'Marketplace',
    },
    {
        Header: 'Create Date',
    },
    {
        Header: 'Status',
    },
]