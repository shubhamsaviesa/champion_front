export const RepricingLogsColumns = [
    {
      Header: 'S.no',
      accessor: 'sn',
      sticky: 'left'
    },
   
    {
      Header: 'Date',
      accessor: 'bookName',
      sticky: 'left'
    },
    {
      Header: 'File Link',
      accessor: 'itemCond',
     
    }
   
  ]