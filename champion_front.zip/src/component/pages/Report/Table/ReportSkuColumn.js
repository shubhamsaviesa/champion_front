export const ReportSkuColumn = [
    {
      Header: 'SKU',
    },
   
    {
      Header: 'Product Name',
    },
    {
      Header: 'Sold',
         
    },
    {
      Header: 'Channel',
    
    },
    {
      Header: 'Sales',
    
    },
    {
      Header: 'Profit Earned',
    
    }
  ]