export const COLUMNS = [
  {
    Header: 'Your Channels',
    accessor:"yourchannel"
  
  }

]


